<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 300px;
        text-align: center;
        margin: auto; 
    }

    h4 {
        margin-bottom: 20px;
        color: #333;
    }

    label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }

    input {
        width: 100%;
        padding: 8px;
        margin-bottom: 16px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #0056b3;
    }

    p {
        margin-top: 20px;
        font-size: 14px;
    }

    a {
        color: #007bff;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }

    img {
        width: 100px; 
        height: auto;
        margin-bottom: 10px;
    }   
</style>

</head>
<body>

<div class="container">

    <div class="form-container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                
                    <div class="card-body">
                        <form action="<?php echo site_url('Login/aksi_login'); ?>" method="POST">
                        <img src="uploads/profil.PNG" alt=" gambar admin">
                        <h4>Login</h4>
                        <p>Masuk sebagai Admin</p>
                                <input type="text" name="username" placeholder="Masukkan Username Anda" required>
                                <input type="text" name="password" placeholder="Masukkan Password Anda" required>
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                            <form action="<?php echo site_url('Register/aksi_register'); ?>" method="POST">
                            <p>Belum punya akun ? <a href="register/aksi_register">Register disini</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
