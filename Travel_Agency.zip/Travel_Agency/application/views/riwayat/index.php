<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "travel";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sql = "SELECT pelanggan.id_pelanggan, pelanggan.nama_pelanggan, pelanggan.email, pemesanan.nama_paket
        FROM pelanggan
        LEFT JOIN pemesanan ON pelanggan.id_pelanggan = pemesanan.id_pemesanan";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan dan Pemesanan</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 70px;
            margin-bottom :130px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<?php
if ($result->num_rows > 0) {
    echo '<table>';
    echo '<tr><th>ID Pelanggan</th><th>Nama Pelanggan</th><th>Email</th><th>Nama Paket</th></tr>';
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row["id_pelanggan"] . '</td>';
        echo '<td>' . $row["nama_pelanggan"] . '</td>';
        echo '<td>' . $row["email"] . '</td>';
        echo '<td>' . $row["nama_paket"] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo "Tidak ada hasil ditemukan";
}

$conn->close();
?>

</body>
</html>
