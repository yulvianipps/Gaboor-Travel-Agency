<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php base_url()?>assets/css/.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #add8e6;
            color: white;
            padding: 50px;
        }

        footer h3 {
            margin-bottom: 10px;
            color: #333333;
        }

        footer p {
            margin-top: 10px;
            color: #333333;
        }

        footer a {
            color: #333333;
        }

        .footer-container {
            background-color: white;
            color: #333333;
            padding: 20px;
        }

        .trusted {
            text-align: center;
        }

        .img-group {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-top: 20px;
        }

        .img-group img {
            max-width: 100px;
            max-height:100px; 
        }
    </style>
</head>

<body>

    <footer>
        <div>
            <a class="navbar-brand" href="index.php"><span class="fw-bold ms-2"
                    style="color: #fe7a15;">Gaboor</span><span
                    class="fw-bold text-primary ms-2">Routes</span></a>
        </div>
        <div>
            <h3>Follow Us</h3>
            <a href="https://www.youtube.com/@yulviani.puteri" target="_blank"><i
                    class="fa fa-youtube" style="margin-right: 10px;"></i></a>
            <a href="#" target="_blank"><i class="fa fa-facebook"
                    style="margin-right: 10px;"></i></a>
            <a href="https://x.com/qwenz_" target="_blank"><i
                    class="fa fa-twitter" style="margin-right: 10px;"></i></a>
            <a href="https://instagram.com/yulvianii" target="_blank"><i
                    class="fa fa-instagram" style="margin-right: 10px;"></i></a>
            <a href="https://www.linkedin.com/in/yulviani-puteri-puspita-sari" target="_blank"><i
                    class="fa fa-linkedin" style="margin-right: 10px;"></i></a>
        </div>
        <p>&copy; 2023 Gaboorroutes. All Rights Reserved.</p>
    </footer>



    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>

</html>
