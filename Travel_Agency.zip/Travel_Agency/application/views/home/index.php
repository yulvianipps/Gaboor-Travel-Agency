<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>Destinasi Wisata</title>
  <style>
    .fixed-top-navbar {
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
    }

    body {
      padding-top: 1px;
    }

    .gaboor-section {
      padding: 80px 0;
      background-color: white;
    }

    .gaboor-item {
      text-align: center;
    }

    .gaboor-icon {
      font-size: 36px;
      color: #007bff;
    }

    .gaboor-title {
      margin-top: 20px;
      font-size: 24px;
      color: #333;
    }

    .gaboor-description {
      margin-top: 20px;
      color: #666;
    }
    
  </style>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      var navbar = document.getElementById("navbar");
      var offset = navbar.offsetTop;

      function handleScroll() {
        if (window.pageYOffset >= offset) {
          navbar.classList.add("fixed-top-navbar");
        } else {
          navbar.classList.remove("fixed-top-navbar");
        }
      }

      window.addEventListener("scroll", handleScroll);
    });
  </script>
</head>

<body>
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="d-block w-100" src="uploads/travel.PNG" alt="Slide Pertama">
      </div>
      <div class="carousel-item">
        <img class="d-block w-100" src="uploads/travel2.jpg" alt="Slide Kedua">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Sebelumnya</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Berikutnya</span>
    </a>
  </div>

  <div class="container mt-5">
    <div class="mt-5 text-center">
      <h2 class="position-relative d-inline-block"> Layanan</h2>
      <p></p>
      <div class="row">
        <div class="col-md-6">
          <a href="<?= base_url('destinasi'); ?>">
            <img src="uploads/tour.jpeg" alt="Tour" class="img-fluid">
          </a>
        </div>
        <div class="col-md-6">
          <a href="<?= base_url('destinasi2'); ?>">
            <img src="uploads/paket.jpeg" alt="Paket Wisata" class="img-fluid" href="<?= base_url() ?>">
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="gaboor-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="gaboor-item">
            <i class="fas fa-map-marked-alt gaboor-icon"></i>
            <h3 class="gaboor-title">Destinasi Indonesia</h3>
            <p class="gaboor-description">Jelajahi keindahan destinasi di Indonesia dengan Gaboor Travel.</p>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="gaboor-item">
            <i class="fas fa-clock gaboor-icon"></i>
            <h3 class="gaboor-title">Waktu Fleksibel</h3>
            <p class="gaboor-description">Nikmati fleksibilitas waktu dalam merencanakan perjalanan Anda.</p>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="gaboor-item">
            <i class="fas fa-dollar-sign gaboor-icon"></i>
            <h3 class="gaboor-title">Harga Terbaik</h3>
            <p class="gaboor-description">Dapatkan harga terbaik untuk paket wisata di Indonesia.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

    <section id = "about" class = "py-5">
        <div class = "container">
            <div class = "row gy-lg-5 align-items-center">
                <div class = "col-lg-6 order-lg-1 text-justify text-lg-start">
                    <div class = "title pt-3 pb-5">
                        <h2>About Us</h2>
                    </div>
                    <p>Gaboor Routes adalah teman setia petualangan Anda, menawarkan pengalaman perjalanan tak terlupakan melalui destinasi menakjubkan. 
                      Sebagai pemandu setia, kami tidak hanya memberikan informasi tentang destinasi, tetapi juga menginspirasi dan membimbing Anda dalam merencanakan perjalanan bermakna. Melalui visualisasi yang indah, 
                      kami menciptakan jendela menuju petualangan sebelum Anda benar-benar menginjakkan kaki di destinasi impian. Gaboor Routes tidak hanya tentang destinasi, tetapi juga tentang cerita perjalanan Anda. 
                      Bergabunglah dengan komunitas pelancong kami, temukan mitra perjalanan, dan rasakan pengalaman tak terlupakan. Selamat datang di Gaboor Routes, di mana setiap klik adalah awal dari petualangan baru.</p>
                </div>
                <div class = "col-lg-6 order-lg-0">
                    <img src = "uploads/bali.jpg" alt = "" class = "img-fluid">
                </div>
            </div>
        </div>
    </section>
    <div class="footer-container">
        <div class="trusted">
        <h4>Gaboor Routes - Travel Agency</h4>
                <p>Menyediakan pengalaman perjalanan terbaik untuk setiap petualangan Anda. <br> Dipercaya oleh pelanggan kami, kami berkomitmen untuk memberikan layanan terbaik dalam merencanakan dan mewujudkan perjalanan impian Anda.</p>
            <div class="img-group">
                <img src="assets/img/Red Doorz.png" alt="Red Doorz">
                <img src="assets/img/garud_indonesia_logo.png" alt="garuda">
                <img src="assets/img/Red Doorz.png" alt="Red Doorz">
                <img src="assets/img/garud_indonesia_logo.png" alt="garuda">
            </div>
        </div>
    </div>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJjtm3YqEveLjL1C5rkkj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>
