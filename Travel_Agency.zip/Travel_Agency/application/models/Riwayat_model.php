<?php

class Riwayat_model extends CI_model {
    public function getAllPemesanan()
    {
        // Menggabungkan data dari tabel 'pelanggan' dan 'pemesanan' berdasarkan kolom 'id_pelanggan'
        $this->db->select('*');
        $this->db->from('pelanggan');
        $this->db->join('pemesanan', 'pelanggan.id_pelanggan = pemesanan.id_pelanggan');
        return $this->db->get()->result_array();
    }

    public function tambahDataPemesanan()
    {
        // Data pelanggan
        $dataPelanggan = [
            "nama_pelanggan" => $this->input->post('nama', true),
            "email" => $this->input->post('email', true),
            "Nomor_telepon" => $this->input->post('NoHp', true),
        ];

        // Insert data pelanggan ke tabel 'pelanggan'
        $this->db->insert('pelanggan', $dataPelanggan);

        // Mendapatkan ID pelanggan yang baru saja ditambahkan
        $idPelanggan = $this->db->insert_id();

        // Data pemesanan
        $dataPemesanan = [
            "nama_paket" => $this->input->post('paket', true),
            "id_pelanggan" => $idPelanggan, // Menghubungkan pemesanan dengan pelanggan
        ];

        // Insert data pemesanan ke tabel 'pemesanan'
        $this->db->insert('pemesanan', $dataPemesanan);
    }

    public function hapusDataPemesanan($id)
    {
        $this->db->delete('pemesanan', ['id' => $id]);
    }

    public function getPemesananById($id)
    {
        return $this->db->get_where('pemesanan', ['id' => $id])->row_array();
    }

    public function ubahDataPemesanan()
    {
        $data = [
            "nama_pelanggan" => $this->input->post('nama', true),
            "email" => $this->input->post('email', true),
            "nama_paket" => $this->input->post('paket', true),
            "Nomor_telepon" => $this->input->post('NoHp', true),
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('pemesanan', $data);
    }
}
