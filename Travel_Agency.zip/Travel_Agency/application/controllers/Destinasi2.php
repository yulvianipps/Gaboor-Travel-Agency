<?php

class Destinasi2 extends CI_Controller
{
    public function index($nama = '')
    {
        $this->load->model('M_produk2'); 
        $data['judul'] = 'Paket';
        $data['nama'] = $nama;
        $data['produk'] = $this->M_produk2->get_produk()->result_array(); 
        $this->load->view('templates/header', $data);
        $this->load->view('destinasi2/index', $data);
        $this->load->view('templates/footer');
    }
}
